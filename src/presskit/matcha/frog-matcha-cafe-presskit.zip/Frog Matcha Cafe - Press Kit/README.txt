Frog Matcha Cafe — Press Kit
カエルの抹茶カフェ / 개구리 말차 카페

4th May Games
https://4thmaygames.com/presskit/matcha/
contact@4thmaygames.com

--------------------------------------------------
CONTENTS
--------------------------------------------------
screenshots/   In-game screenshots (1080x1920 PNG)
artwork/       Key artwork and illustrations
logo/          App icon, key art, studio logo

--------------------------------------------------
USAGE
--------------------------------------------------
These assets may be used freely in articles, reviews
and coverage of the game. Please contact us before
using them in modified form.

本素材はゲーム紹介記事・レビュー等での使用を許諾しています。
改変を伴う使用の際は事前にご連絡ください。

이 에셋은 게임 소개 기사와 리뷰에 자유롭게 사용하실 수 있습니다.
변형해 사용하실 경우 사전에 연락 부탁드립니다.

(c) 2026 4th May Games. All rights reserved.
